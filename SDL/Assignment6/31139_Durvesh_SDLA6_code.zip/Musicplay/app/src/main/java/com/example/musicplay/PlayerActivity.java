package com.example.musicplay;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.PorterDuff;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;

public class PlayerActivity extends AppCompatActivity {

    Button btn_pause,btn_previous,btn_next;
    TextView songName;
    SeekBar songSeekBar;
    static MediaPlayer mediaPlayer;
    int position;
    String sname;
    ArrayList<File> mysongs;
    Thread updateSeekbar;

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player);
        btn_next = findViewById(R.id.next);
        btn_pause = findViewById(R.id.pause);
        btn_previous = findViewById(R.id.previous);
        songName = findViewById(R.id.songlabel);
        songSeekBar = findViewById(R.id.seekbar);
        getSupportActionBar().setTitle("Now Playing");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setDisplayShowHomeEnabled(true);


        updateSeekbar = new Thread(){
            @Override
            public void run() {

                int totalDuration = mediaPlayer.getDuration();
                int currentPosition = 0;
                while(currentPosition<totalDuration){
                    try{
                        sleep(500);
                        currentPosition = mediaPlayer.getCurrentPosition();
                        songSeekBar.setProgress(currentPosition);
                    }catch (InterruptedException e){
                        e.printStackTrace();
                    }
                }

            }
        };

        if(mediaPlayer!=null){
            mediaPlayer.stop();
            mediaPlayer.release();
        }

        Intent i = getIntent();
        Bundle bundle = i.getExtras();
        mysongs = (ArrayList) bundle.getParcelableArrayList("songs");
        sname = mysongs.get(position).getName().toString();
        String songname = i.getStringExtra("song").replace(".mp3","");
        songName.setText(songname);
        songName.setSelected(true);
        position = bundle.getInt("pos",0);
        Uri uri = Uri.parse(mysongs.get(position).toString());
        Context context;
        mediaPlayer = MediaPlayer.create(getApplicationContext(), uri);
        mediaPlayer.start();
        songSeekBar.setMax(mediaPlayer.getDuration());
        updateSeekbar.start();

        songSeekBar.getProgressDrawable().setColorFilter(getResources().getColor(android.R.color.white), PorterDuff.Mode.MULTIPLY);
        songSeekBar.getThumb().setColorFilter(getResources().getColor(android.R.color.white),PorterDuff.Mode.SRC_IN);

        songSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                mediaPlayer.seekTo(seekBar.getProgress());
            }
        });
        btn_pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                songSeekBar.setMax(mediaPlayer.getDuration());
                if(mediaPlayer.isPlaying()){
                    btn_pause.setBackgroundResource(R.drawable.iconplay);
                    mediaPlayer.pause();
                }
                else{
                    btn_pause.setBackgroundResource(R.drawable.iconpause);
                    mediaPlayer.start();
                }
            }
        });
        btn_next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                mediaPlayer.release();
                position = (position+1)%mysongs.size();
                Uri uri1 = Uri.parse(mysongs.get(position).toString());

                mediaPlayer = MediaPlayer.create(getApplicationContext(),uri1);
                sname = mysongs.get(position).getName().toString().replace(".mp3","");
                songName.setText(sname);
                mediaPlayer.start();

            }
        });
        btn_previous.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mediaPlayer.stop();
                mediaPlayer.release();
                position = (position-1)%mysongs.size();
                Uri uri1 = Uri.parse(mysongs.get(position).toString());

                mediaPlayer = MediaPlayer.create(getApplicationContext(),uri1);
                sname = mysongs.get(position).getName().toString().replace(".mp3","");
                songName.setText(sname);
                mediaPlayer.start();
            }
        });


    }
}